# EliteD

EliteD is a package to make database usage easier!
Easily create database and read and update them